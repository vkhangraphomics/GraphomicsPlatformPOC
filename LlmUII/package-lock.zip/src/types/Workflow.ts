export default interface IWorkflowData {
  id?: any | null,
  title: string,
  description: string,
}